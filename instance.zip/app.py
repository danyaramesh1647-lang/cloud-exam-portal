from flask import Flask, render_template, request, redirect, url_for, flash
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from database import db, User, Exam, Question, Submission

app = Flask(__name__)

# ---------------- Configuration ----------------
app.config['SECRET_KEY'] = 'dev-secret-key-change-later'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///exam_portal.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# ---------------- Initialize Extensions ----------------
db.init_app(app)

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'


@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))


with app.app_context():
    db.create_all()


# ---------------- Home ----------------
@app.route('/')
def home():
    return redirect(url_for('login'))


# ---------------- Register ----------------
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']
        role = request.form['role']

        existing_user = User.query.filter_by(email=email).first()

        if existing_user:
            flash('Email already registered. Please login.')
            return redirect(url_for('login'))

        hashed_pw = generate_password_hash(password)

        new_user = User(
            name=name,
            email=email,
            password_hash=hashed_pw,
            role=role
        )

        db.session.add(new_user)
        db.session.commit()

        flash('Registration successful! Please login.')
        return redirect(url_for('login'))

    return render_template('register.html')


# ---------------- Login ----------------
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':

        email = request.form['email']
        password = request.form['password']

        user = User.query.filter_by(email=email).first()

        if user and check_password_hash(user.password_hash, password):
            login_user(user)

            # Send everyone to dashboard.
            # Dashboard decides whether they are admin or student.
            return redirect(url_for('dashboard'))

        flash('Invalid email or password.')

    return render_template('login.html')


# ---------------- Dashboard ----------------
@app.route('/dashboard')
@login_required
def dashboard():

    if current_user.role == "admin":
        return render_template("admin_dashboard.html")

    return render_template("dashboard.html")

# ---------------- Create Exam ----------------
@app.route('/create-exam', methods=['GET', 'POST'])
@login_required
def create_exam():

    if current_user.role != 'admin':
        flash('Only admins can create exams.')
        return redirect(url_for('dashboard'))

    if request.method == 'POST':

        title = request.form['title']
        duration = request.form['duration']

        new_exam = Exam(
            title=title,
            duration_minutes=duration,
            created_by=current_user.id
        )

        db.session.add(new_exam)
        db.session.commit()

        flash('Exam created! Now add some questions.')

        return redirect(url_for('add_question', exam_id=new_exam.id))

    return render_template('create_exam.html')


# ---------------- Add Questions ----------------
@app.route('/add-question/<int:exam_id>', methods=['GET', 'POST'])
@login_required
def add_question(exam_id):

    if current_user.role != 'admin':
        flash('Only admins can add questions.')
        return redirect(url_for('dashboard'))

    exam = db.session.get(Exam, exam_id)

    if not exam:
        flash('Exam not found.')
        return redirect(url_for('dashboard'))

    if request.method == 'POST':

        new_question = Question(
            exam_id=exam.id,
            question_text=request.form['question_text'],
            option_a=request.form['option_a'],
            option_b=request.form['option_b'],
            option_c=request.form['option_c'],
            option_d=request.form['option_d'],
            correct_option=request.form['correct_option']
        )

        db.session.add(new_question)
        db.session.commit()

        flash('Question added!')

        return redirect(url_for('add_question', exam_id=exam.id))

    return render_template('add_question.html', exam=exam)


# ---------------- Publish Exam ----------------
@app.route('/publish-exam/<int:exam_id>')
@login_required
def publish_exam(exam_id):

    if current_user.role != 'admin':
        flash('Only admins can publish exams.')
        return redirect(url_for('dashboard'))

    exam = db.session.get(Exam, exam_id)

    if not exam:
        flash('Exam not found.')
        return redirect(url_for('dashboard'))

    if exam.created_by != current_user.id:
        flash('You can only publish exams you created.')
        return redirect(url_for('dashboard'))

    exam.is_published = True
    db.session.commit()

    flash(f'"{exam.title}" is now published!')

    return redirect(url_for('add_question', exam_id=exam.id))


# ---------------- Exam List ----------------
@app.route('/exams')
@login_required
def exam_list():
    exams = Exam.query.filter_by(is_published=True).all()
    return render_template('exam_list.html', exams=exams)

# ---------------- Take Exam ----------------
@app.route('/take-exam/<int:exam_id>', methods=['GET', 'POST'])
@login_required
def take_exam(exam_id):

    if current_user.role != 'student':
        flash('Only students can take exams.')
        return redirect(url_for('dashboard'))

    exam = db.session.get(Exam, exam_id)

    if not exam or not exam.is_published:
        flash('Exam not found.')
        return redirect(url_for('exam_list'))

    questions = Question.query.filter_by(exam_id=exam.id).all()

    if request.method == 'POST':

        score = 0

        submission = Submission(
            student_id=current_user.id,
            exam_id=exam.id
        )

        db.session.add(submission)
        db.session.commit()

        from database import Answer

        for question in questions:

            selected = request.form.get(f'question_{question.id}')

            answer = Answer(
                submission_id=submission.id,
                question_id=question.id,
                selected_option=selected
            )

            db.session.add(answer)

            if selected == question.correct_option:
                score += 1

        submission.score = score

        db.session.commit()

        flash(f'Exam submitted successfully! Your score is {score}/{len(questions)}')

        return redirect(url_for('exam_list'))

    return render_template(
        'take_exam.html',
        exam=exam,
        questions=questions
    )

# ---------------- Logout ----------------
@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

# ---------------- Run App ----------------
if __name__ == '__main__':
    app.run(debug=True, port=5001)